public enum AccountType {
    Checking,
    Savings,
    Undefined
}
